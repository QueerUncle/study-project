/*
  @Author: lize
  @Date: 2021/5/29
  @Description :
  @Parames :
  @Example :
  @Last Modified by: lize
  @Last Modified time: 2021/5/29
*/
import {
  h, nextTick, onBeforeUnmount, onMounted, reactive, ref,
} from 'vue';
import Sortable from 'sortablejs';

const eventsListened = ['Start', 'Add', 'Update'];
const eventsEmits = ['End', 'Remove', 'Sort', 'Filter', 'Move', 'Clone', 'Change', 'Unchoose', 'Choose'];
const eventEmitsOptions = (ctx) => eventsEmits.reduce((res, item) => { // eslint-disable-line
  res[`on${item}`] = (evt) => ctx.emit(`drag${item}`, evt); // eslint-disable-line
  return res;
}, {});
const eventsListenerOptions = (eventObj) => eventsListened.reduce((res, evt) => { // eslint-disable-line
  res[`on${evt}`] = eventObj[`onDrag${evt}`]; // eslint-disable-line
  return res;
}, {});
const createEmits = () => [...eventsListened, ...eventsEmits].reduce((res, evt) => {
  res.push(`drag${evt}`);
  return res;
}, []);

const draggableComponent = {
  name: 'Draggable',
  inheritAttrs: false,
  props: {
    tag: {
      type: String,
      default: 'div',
      require: true,
    },
    group: {
      type: Object,
      default: () => ({
        name: 'form',
        pull: 'clone',
        put: false,
      }),
    },
    ghostClass: {
      type: String,
      default: '',
    },
    sort: {
      type: Boolean,
      default: false,
    },
    animation: {
      type: Number,
      default: 150,
    },
    list: {
      type: Array,
      default: () => ([]),
    },
    clone: {
      type: Function,
      default: (cloneData) => (cloneData),
    },
  },
  emits: createEmits(),
  render() {
    const {
      $slots, getTag, $attrs, prefix,
    } = this;
    return h(getTag(), { ...$attrs, id: `${prefix}-${getTag()}-wrap` }, $slots.default());
  },
  setup(props: any, ctx) {
    // 数据参数
    const ResultList = reactive(props.list);
    // 实例
    const SortableTarget = ref();
    // 获取随机字符串
    const randCode = () => {
      const result = [];
      for (let i = 0; i < 4; i += 1) {
        const ranNum = Math.ceil(Math.random() * 25);
        result.push(String.fromCharCode(65 + ranNum));
      }
      return result.join('');
    };
    // 前缀
    const prefix = randCode();
    // 获取要渲染的标签名
    const getTag = () => {
      if (!props.tag) {
        console.log(ctx.slots.default());
      }
      return props.tag || 'div';
    };
    // 对比寻找dom下标
    const findNodeIndex = (nodeAry, targetNode) => nodeAry.indexOf(targetNode);
    // 获取所有子节点
    const getChildrenNodes = (element) => [].slice.call(element.children);
    // 获取原始节点的下表及数据
    const getOldNodeIndexAndData = (evt) => {
      const index = findNodeIndex(getChildrenNodes(evt.from), evt.item);
      if (index === -1) return null;
      const data = ResultList[index];
      return { index, data };
    };
    const removeNode = (node) => {
      if (node.parentElement !== null) {
        node.parentElement.removeChild(node);
      }
    };
    const eventObj = reactive({
      // 拖动开始
      onDragStart(evt) {
        const { data } = getOldNodeIndexAndData(evt);
        evt.item._underlying_vm_ = props.clone(data); // eslint-disable-line
        ctx.emit('dragStart', evt);
      },
      // 元素从一个列表拖拽到另一个列表
      onDragAdd(evt) {
        const data = evt.item._underlying_vm_; // eslint-disable-line
        if (!data) return;
        // eslint-disable-next-line no-use-before-define
        removeNode(evt.item);
        if (!evt.originalEvent.cancelable) return;
        ctx.emit('dragAdd', { data, newIndex: evt.newIndex, oldIndex: evt.oldIndex });
      },
      // 列表内元素顺序更新的时候触发
      async onDragUpdate(evt) {
        const oldData = ResultList[evt.oldIndex]; // eslint-disable-line
        ResultList.splice(evt.oldIndex, 1);
        await nextTick();
        ResultList.splice(evt.newIndex, 0, oldData);
        ctx.emit('dragUpdate', evt);
      },
    });
    onBeforeUnmount(() => {
      if (SortableTarget.value) SortableTarget.value.destroy();
    });
    onMounted(async () => {
      await nextTick();
      await setTimeout(async () => {
        const targetNode = document.querySelector(`#${prefix}-${getTag()}-wrap`);
        const options = { ...props, ...eventEmitsOptions(ctx), ...eventsListenerOptions(eventObj) };
        SortableTarget.value = await new Sortable(targetNode, options);
      }, 500);
    });
    return {
      getTag,
      prefix,
      ...eventObj,
    };
  },
};
export default draggableComponent;
