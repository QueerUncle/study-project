/*
  @Author: lize
  @Date: 2021/5/29
  @Description :
  @Parames :
  @Example :
  @Last Modified by: lize
  @Last Modified time: 2021/5/29
*/
import {
  h, nextTick, onBeforeUnmount, onMounted, reactive, ref,
} from 'vue';
import Sortable from 'sortablejs';

const eventsListened = ['Start', 'End', 'Add', 'Update', 'Sort', 'Remove', 'Filter', 'Move', 'Clone', 'Change'];
const eventOptions = (props, ctx, eventObj) => eventsListened.reduce((res, evt) => {
  res[`on${evt}`] = eventObj[`onDrag${evt}`]; // eslint-disable-line
  return res;
}, {});
const createEmits = () => eventsListened.reduce((res, evt) => {
  res.push(`drag${evt}`);
  return res;
}, []);

const draggableComponent = {
  name: 'Draggable',
  inheritAttrs: false,
  props: {
    tag: {
      type: String,
      default: null,
    },
    group: {
      type: Object,
      default: () => ({
        name: 'form',
        pull: 'clone',
        put: false,
      }),
    },
    ghostClass: {
      type: String,
      default: '',
    },
    sort: {
      type: Boolean,
      default: false,
    },
    animation: {
      type: Number,
      default: 150,
    },
    list: {
      type: Array,
      default: () => ([]),
    },
    clone: {
      type: Function,
      default: (cloneData) => (cloneData),
    },
  },
  emits: createEmits(),
  render() {
    const {
      $slots, getTag, $attrs, prefix,
    } = this;
    return h(getTag(), { ...$attrs, id: `${prefix}-${getTag()}-wrap` }, $slots.default());
  },
  setup(props: any, ctx) {
    // 数据参数
    const ResultList = reactive(props.list);
    // 实例
    const SortableTarget = ref();
    // 获取随机字符串
    const randCode = () => {
      const result = [];
      for (let i = 0; i < 4; i += 1) {
        const ranNum = Math.ceil(Math.random() * 25);
        result.push(String.fromCharCode(65 + ranNum));
      }
      return result.join('');
    };
    // 前缀
    const prefix = randCode();
    // 获取要渲染的标签名
    const getTag = () => {
      if (!props.tag) {
        console.log(ctx.slots.default());
      }
      return props.tag || 'div';
    };
    // 对比寻找dom下标
    const findNodeIndex = (nodeAry, targetNode) => nodeAry.indexOf(targetNode);
    // 获取所有子节点
    const getChildrenNodes = (element) => [].slice.call(element.children);
    // 获取原始节点的下表及数据
    const getOldNodeIndexAndData = (evt) => {
      const index = findNodeIndex(getChildrenNodes(evt.from), evt.item);
      if (index === -1) return null;
      const data = ResultList[index];
      return { index, data };
    };
    const eventObj = reactive({
      onDragChoose(evt) {
        // console.log(evt);
        ctx.emit('dragChoose', evt);
      },
      onDragUnchoose(evt) {
        // console.log(evt);
        ctx.emit('dragUnchoose', evt);
      },
      // 拖动开始
      onDragStart(evt) {
        const { data } = getOldNodeIndexAndData(evt);
        evt.item._underlying_vm_ = props.clone(data); // eslint-disable-line
        ctx.emit('dragStart', evt);
      },
      // 结束拖拽
      onDragEnd(evt) {
        ctx.emit('dragEnd', evt);
      },
      // 元素从一个列表拖拽到另一个列表
      onDragAdd(evt) {
        const data = evt.item._underlying_vm_; // eslint-disable-line
        if (!data) return;
        // eslint-disable-next-line no-use-before-define
        removeNode(evt.item);
        ctx.emit('dragAdd', { data, newIndex: evt.newIndex, oldIndex: evt.oldIndex });
      },
      // 列表内元素顺序更新的时候触发
      async onDragUpdate(evt) {
        const oldData = ResultList[evt.oldIndex]; // eslint-disable-line
        ResultList.splice(evt.oldIndex, 1);
        await nextTick();
        ResultList.splice(evt.newIndex, 0, oldData);
        ctx.emit('dragUpdate', evt);
      },
      // 列表的任何更改都会触发
      onDragSort(evt) {
        ctx.emit('dragSort', evt);
      },
      // 元素从列表中移除进入另一个列表
      onDragRemove(evt) {
        ctx.emit('dragRemove', evt);
      },
      // 试图拖拽一个filtered的元素
      onDragFilter(evt) {
        // console.log(evt, 'onFilter');
        ctx.emit('dragFilter', evt);
      },
      // 拖拽移动的时候
      onDragMove(evt) {
        // console.log(evt, 'onDragMove');
        ctx.emit('dragMove', evt);
      },
      // clone一个元素的时候触发
      onDragClone(evt) {
        // console.log(evt, 'onClone');
        ctx.emit('dragClone', evt);
      },
      onDragChange(evt) {
        // console.log(evt, 'onChange');
        ctx.emit('dragChange', evt);
      },
    });
    const removeNode = (node) => {
      if (node.parentElement !== null) {
        node.parentElement.removeChild(node);
      }
    };
    onBeforeUnmount(() => {
      if (SortableTarget.value) SortableTarget.value.destroy();
    });
    onMounted(async () => {
      await nextTick();
      await setTimeout(async () => {
        const targetNode = document.querySelector(`#${prefix}-${getTag()}-wrap`);
        const options = { ...props, ...eventOptions(props, ctx, eventObj) };
        SortableTarget.value = await new Sortable(targetNode, options);
      }, 500);
    });
    return {
      getTag,
      prefix,
      ...eventObj,
    };
  },
};
export default draggableComponent;
